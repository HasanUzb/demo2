import random
a = random.randint(1, 100)
while True:
    try:
        s = int(input("1 dan 100 gacha bo'lgan son kiriting: "))
        if s < a:
            print("Kichik!")
        elif s > a:
            print("Katta!")
        else:
            print("To'g'ri topdingiz!")
            break
    except ValueError:
        print("Xato!")
