from datetime import datetime, timedelta

hozirgi_vaqt = datetime.now()

kecha = hozirgi_vaqt- timedelta(days=1)

print("Joriy sana va vaqt:", hozirgi_vaqt.strftime("%Y-%m-%d %H:%M:%S"))
print("Bir kun oldingi sana:", kecha.strftime("%Y-%m-%d %H:%M:%S"))
