try:
    a = int(input("Butun son kiriting: "))
    print(f"Siz butun son kiritingiz: {a}")
except ValueError:
    print("Bu son emas!")

