list = (input("Sonlar:"))

try:
    print(list[30])
except ValueError:
    print("Noto'g'ri qiymat kiritildi!")
except IndexError:
    print("Mavjud bo'lmasan index ishlatildi")
