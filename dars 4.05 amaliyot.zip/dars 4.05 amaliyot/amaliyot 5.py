try:
    a = int(input("1-qiymatni kiriting: "))
    b = int(input("2_qiymatni kiriting: "))
    result = a / b
    print(f"Natija: {result}")
except ValueError:
    print("Bu son emas!")
except TypeError:
    print(" Ikkala qiymat son bolishi kere")
except ZeroDivisionError:
    print("Nolga bo'lib bolmaydi")

