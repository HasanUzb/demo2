dic1 = ['S001', 'S002', 'S003', 'S004']
list1 = ['Adina Park', 'Leyton Marsh', 'Duncan Boyle', 'Saim Richards']
list2 = [85, 98, 89, 92]

result = []

for i in range(len(dic1)):
    result.append({dic1[i]: {list1[i]: list2[i]}})

print(result)
