berilgan_string = 'w3resource'
count = {}


for char in berilgan_string:
    if char in count:
        count[char] += 1
    else:
        count[char] = 1

print(count)
