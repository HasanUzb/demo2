def juft_toq_funksiya(input_dict):

    natija_dict = {}

    for son in range(1, len(input_dict) + 1):
        if son % 2 == 0:

            natija_dict[son] = input_dict[son - 1]
        else:

            if son + 1 in input_dict:
                natija_dict[son] = input_dict[son + 1]
            else:
                natija_dict[son] = input_dict[son]

    return natija_dict

dict1 = {1: 'ABC', 2: 'DEF', 3: 'GHI', 4: 'JKL', 5: 'MNO'}

output = juft_toq_funksiya(dict1)
print(output)
