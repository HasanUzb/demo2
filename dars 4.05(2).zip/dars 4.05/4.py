def soz_gap(input_string):

    sozlar = []
    gaplar = []

    gap_list = input_string.split('. ')

    for gap in gap_list:
        gaplar.append(gap.strip())
        sozlar_gapni_ichidagi = gap.split()
        sozlar.extend(sozlar_gapni_ichidagi)

    return sozlar, gaplar

input_string = "Salom Yoz. Olam juda ham go'zallik. Imtihon bo'lyapti."

sozlar_list, gaplar_list = soz_gap(input_string)

print("Barcha so'zlar:", sozlar_list)
print("Barcha gaplar:", gaplar_list)
