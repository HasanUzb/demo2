def kotta_son(numbers):
    sorted_numbers = sorted(map(str, numbers), reverse=True)
    return int(''.join(sorted_numbers))

son1 = [1, 2, 3]
son2 = [61, 228, 9]

output1 = kotta_son(son1)
output2 = kotta_son(son2)

print(output1)
print(output2)
