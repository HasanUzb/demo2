def birinchi_raqami_juftlar(numbers):

    result = []

    for num in numbers:
        birinchisi_juft = int(str(num)[0])
        if birinchisi_juft % 2 == 0:
            result.append(num)

    return result

input_numbers = [123, 456, 789, 852, 12, 42, 61, 369]

output = birinchi_raqami_juftlar(input_numbers)
print(output)
