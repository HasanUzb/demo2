def raqamni_oqish(num):
    if num == 0:
        return "nol"

    birlar = ["", "bir", "ikki", "uch", "to'rt", "besh", "olti", "yetti", "sakkiz", "to'qqiz"]
    on = ["o'n", "o'n bir", "o'n ikki", "o'n uch", "o'n to'rt", "o'n besh", "o'n olti", "o'n yetti", "o'n sakkiz", "o'n to'qqiz"]
    onlar = ["", "", "yigirma", "o'ttiz", "qirq", "ellik", "oltmish", "yetmish", "sakson", "to'qson"]
    minglar = ["", "ming", "million", "milliard"]

    words = []

    if num >= 1000000000:
        return "Berilgan son 1,000,000,000 dan kotta ekan"

    for idx, ming in enumerate(minglar):
        part = num % 1000
        if part > 0:
            words.append(yuz(part, birlar, on, onlar) + (' ' + ming if ming else ''))
        num //= 1000

    return ' '.join(reversed(words)).strip()


def yuz(num, birlar, on, onlar):
    if num >= 100:
        return birlar[num // 100] + " yuz" + (' ' + onla(num % 100, birlar, onla, onlar) if num % 100 > 0 else '')
    else:
        return onla(num, birlar, onla, onlar)


def onla(num, birlar, onla, onlar):
    if num < 10:
        return birlar[num]
    elif num < 20:
        return onla[num - 10]
    else:
        return onlar[num // 10] + (' ' + birlar[num % 10] if num % 10 > 0 else '')

input_num = int(input("Sonni kiriting (1-1000000000): "))
print(raqamni_oqish(input_num))
